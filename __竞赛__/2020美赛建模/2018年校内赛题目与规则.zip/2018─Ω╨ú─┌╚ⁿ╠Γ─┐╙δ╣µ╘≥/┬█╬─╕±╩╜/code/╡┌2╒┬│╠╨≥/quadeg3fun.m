function  y=quadeg3fun(x)
y=exp(-x.^2);