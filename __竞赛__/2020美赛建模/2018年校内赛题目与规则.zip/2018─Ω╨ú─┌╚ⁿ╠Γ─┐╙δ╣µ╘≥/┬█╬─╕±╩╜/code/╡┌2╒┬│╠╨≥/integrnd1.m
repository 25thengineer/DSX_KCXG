function out = integrnd1(x, y)
out = y*sin(x)+x*cos(y);