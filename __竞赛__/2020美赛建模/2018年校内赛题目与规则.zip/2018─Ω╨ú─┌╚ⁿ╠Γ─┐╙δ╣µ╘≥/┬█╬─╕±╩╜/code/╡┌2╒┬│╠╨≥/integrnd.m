function z = integrnd(x, y) 
z = y*sin(x)+x*cos(y);
