function dydx = ode2(x,y)
dydx = -y.^2;