function dydx = ode1(x,y)
dydx = x+y;