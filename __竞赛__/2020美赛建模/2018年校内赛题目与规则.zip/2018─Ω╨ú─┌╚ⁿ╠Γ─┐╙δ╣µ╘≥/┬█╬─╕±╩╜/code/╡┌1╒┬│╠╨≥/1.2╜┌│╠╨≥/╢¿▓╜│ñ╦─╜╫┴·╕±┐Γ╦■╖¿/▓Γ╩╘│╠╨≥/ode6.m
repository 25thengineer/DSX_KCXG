function dydx = ode6(x,y)
dydx = -20*y + 20*sin(x) + cos(x);