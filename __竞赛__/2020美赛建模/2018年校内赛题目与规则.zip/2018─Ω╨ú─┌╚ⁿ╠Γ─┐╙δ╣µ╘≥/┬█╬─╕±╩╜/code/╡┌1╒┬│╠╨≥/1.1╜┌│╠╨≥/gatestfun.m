function y = gatestfun(x)
p1=0.5;
p2=6.0;
y = p1*x(1)^2 + x(2)^2 -x(1)*x(2) -2*x(1) - p2*x(2);