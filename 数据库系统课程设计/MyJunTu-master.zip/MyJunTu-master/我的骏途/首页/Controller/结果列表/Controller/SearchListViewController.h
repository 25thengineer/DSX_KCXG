//
//  SearchListViewController.h
//  我的骏途
//
//  Created by mac on 15/10/15.
//  Copyright (c) 2015年 wendan. All rights reserved.
//

#import "BaseViewController.h"

@interface SearchListViewController : BaseViewController

@property(nonatomic,copy)NSString *searchTitle;
@property(nonatomic,strong)NSDictionary *dictionary;
@end
