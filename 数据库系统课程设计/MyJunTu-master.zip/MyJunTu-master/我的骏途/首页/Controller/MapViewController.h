//
//  MapViewController.h
//  骏途旅游
//
//  Created by mac on 15/10/13.
//  Copyright (c) 2015年 huiwen. All rights reserved.
//

#import "BaseViewController.h"


@interface MapViewController : BaseViewController

@property (nonatomic,copy)NSString *placeName;

@end
