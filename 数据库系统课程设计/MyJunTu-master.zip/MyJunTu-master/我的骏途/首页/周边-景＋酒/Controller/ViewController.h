//
//  ViewController.h
//  周边游
//
//  Created by 俞烨梁 on 15/10/22.
//  Copyright (c) 2015年 俞烨梁. All rights reserved.
//

#import "BaseViewController.h"

@interface ViewController : BaseViewController

@property (nonatomic,copy)NSString *showType;
@end

