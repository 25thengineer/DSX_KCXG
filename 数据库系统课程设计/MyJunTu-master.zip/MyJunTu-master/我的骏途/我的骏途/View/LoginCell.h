//
//  LoginCell.h
//  骏途旅游
//
//  Created by mac on 15/10/11.
//  Copyright (c) 2015年 huiwen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginCell : UITableViewCell

@property (nonatomic,strong) UILabel *label;

@property (nonatomic,strong) UITextField *textF;




@end
