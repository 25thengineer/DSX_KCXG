//
//  OrderListViewController.h
//  我的骏途
//
//  Created by mac on 15/10/11.
//  Copyright (c) 2015年 wendan. All rights reserved.
//

#import "BaseViewController.h"

@interface OrderListViewController : BaseViewController
@property(nonatomic , copy)NSString *orderTitle;
@property (nonatomic,copy)NSString *order_type;
@end
