//
//  UIView+UIViewController.h
//  WeiBobo
//
//  Created by mac on 15/10/16.
//  Copyright (c) 2015年 wendan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (UIViewController)

-(UIViewController *)viewController;
@end
